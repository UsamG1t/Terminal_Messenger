Terminal Messenger API
======================

Terminal Messenger Server
-------------------------

.. automodule:: msg.server
   :members:
   :private-members:

Terminal Messenger Common
-------------------------

.. automodule:: msg.common
   :members:
   :private-members:

Terminal Messenger Client
-------------------------

.. automodule:: msg.client
   :members:
   :private-members:
