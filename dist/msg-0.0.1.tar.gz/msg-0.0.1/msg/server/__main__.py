"""Start server."""
from . import start

start()
